package testdb;

public interface ScreenController {

	// This method will allow the injection of the ScreenPane
	public void setScreenPane(ScreenPane screenPage);
}
